/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import appalumno.Alumno;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author USUARIO
 */
public class TestAlumno {
    
    public TestAlumno() {
    }
    
    @Test
    public void probarPromedio(){
        Alumno alumno= new Alumno("001", "pepe ", 18.00 , 16.00);
        double resultado;
        resultado = alumno.calcularPromedio();
        assertEquals((18+16)/2,resultado,0.00);
        
    }
}
