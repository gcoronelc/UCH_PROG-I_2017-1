/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appalumno;

/**
 *
 * @author USUARIO
 */
public class Alumno {
    private String codigo;
    private String nombre;
    private double notaParcial;
    private double notaFinal;

    public Alumno(String codigo, String nombre, double notaParcial, double sumaFinal) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.notaParcial = notaParcial;
        this.notaFinal = sumaFinal;
    }
    
    public double calcularPromedio(){
        return (this.notaParcial + this.notaFinal)/2;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNotaParcial() {
        return notaParcial;
    }

    public void setNotaParcial(double notaParcial) {
        this.notaParcial = notaParcial;
    }

    public double getSumaFinal() {
        return notaFinal;
    }

    public void setSumaFinal(double sumaFinal) {
        this.notaFinal = sumaFinal;
    }
    
    
}
